<?php /* Smarty version Smarty-3.1.14, created on 2014-04-21 15:44:37
         compiled from "D:\VPS\ptiendaline\modules\homeslider\views\templates\hook\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1881453558335b168a4-60748021%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8da15fa5876f8221304e683087f42ae1de9bab47' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\modules\\homeslider\\views\\templates\\hook\\header.tpl',
      1 => 1397074247,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1881453558335b168a4-60748021',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'homeslider' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_53558335b550b2_72951182',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53558335b550b2_72951182')) {function content_53558335b550b2_72951182($_smarty_tpl) {?><?php if (isset($_smarty_tpl->tpl_vars['homeslider']->value)){?>
<script type="text/javascript">
     var homeslider_loop=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['loop'];?>
;
     var homeslider_width=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['width'];?>
;
     var homeslider_speed=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['speed'];?>
;
     var homeslider_pause=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['pause'];?>
;
</script>
<?php }?><?php }} ?>