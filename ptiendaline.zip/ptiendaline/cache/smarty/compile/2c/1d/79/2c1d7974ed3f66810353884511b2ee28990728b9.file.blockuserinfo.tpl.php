<?php /* Smarty version Smarty-3.1.14, created on 2014-04-21 15:44:38
         compiled from "D:\VPS\ptiendaline\themes\plan1-tema1\modules\blockuserinfo\blockuserinfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32650535583360be2d4-92089754%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2c1d7974ed3f66810353884511b2ee28990728b9' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\themes\\plan1-tema1\\modules\\blockuserinfo\\blockuserinfo.tpl',
      1 => 1395935302,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32650535583360be2d4-92089754',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_535583360be2d4_74282238',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535583360be2d4_74282238')) {function content_535583360be2d4_74282238($_smarty_tpl) {?><?php }} ?>