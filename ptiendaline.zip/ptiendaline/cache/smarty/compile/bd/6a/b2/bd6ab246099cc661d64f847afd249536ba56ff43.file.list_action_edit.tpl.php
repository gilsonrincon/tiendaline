<?php /* Smarty version Smarty-3.1.14, created on 2014-04-14 16:09:55
         compiled from "D:\VPS\ptiendaline\admin8317\themes\default\template\helpers\list\list_action_edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:207534c4ea3ced105-72300864%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd6ab246099cc661d64f847afd249536ba56ff43' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\admin8317\\themes\\default\\template\\helpers\\list\\list_action_edit.tpl',
      1 => 1395094664,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '207534c4ea3ced105-72300864',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'href' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534c4ea3cf4e08_22339124',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534c4ea3cf4e08_22339124')) {function content_534c4ea3cf4e08_22339124($_smarty_tpl) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['href']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" class="edit">
	<i class="icon-pencil"></i> <?php echo $_smarty_tpl->tpl_vars['action']->value;?>

</a><?php }} ?>