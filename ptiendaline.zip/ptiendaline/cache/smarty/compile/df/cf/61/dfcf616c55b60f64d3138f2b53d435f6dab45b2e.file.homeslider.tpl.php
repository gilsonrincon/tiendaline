<?php /* Smarty version Smarty-3.1.14, created on 2014-04-21 15:44:38
         compiled from "D:\VPS\ptiendaline\themes\plan1-tema1\modules\homeslider\homeslider.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2437853558336780be2-23129852%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dfcf616c55b60f64d3138f2b53d435f6dab45b2e' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\themes\\plan1-tema1\\modules\\homeslider\\homeslider.tpl',
      1 => 1397141436,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2437853558336780be2-23129852',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'page_name' => 0,
    'homeslider_slides' => 0,
    'slide' => 0,
    'first' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_535583367c3276_13821829',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535583367c3276_13821829')) {function content_535583367c3276_13821829($_smarty_tpl) {?>
<?php if ($_smarty_tpl->tpl_vars['page_name']->value=='index'){?>
    <!-- Module HomeSlider -->
    <?php if (isset($_smarty_tpl->tpl_vars['homeslider_slides']->value)){?>
        <div id="bannerHome" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php $_smarty_tpl->tpl_vars["first"] = new Smarty_variable(true, null, 0);?>
                <?php  $_smarty_tpl->tpl_vars['slide'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['slide']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['homeslider_slides']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['slide']->key => $_smarty_tpl->tpl_vars['slide']->value){
$_smarty_tpl->tpl_vars['slide']->_loop = true;
?>
                    <?php if ($_smarty_tpl->tpl_vars['slide']->value['active']){?>
                        <div class="item<?php if ($_smarty_tpl->tpl_vars['first']->value==true){?> active<?php }?>">
                            <a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['url'], ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['legend'], ENT_QUOTES, 'UTF-8', true);?>
">
                                <img src="<?php echo $_smarty_tpl->tpl_vars['link']->value->getMediaLink(((string)@constant('_MODULE_DIR_'))."homeslider/img/".((string)mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['image'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8')));?>
" width="100%" height="100%" alt="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['legend'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" />
                            </a>
                            <div class="carousel-caption">
                                <?php if (isset($_smarty_tpl->tpl_vars['slide']->value['description'])&&trim($_smarty_tpl->tpl_vars['slide']->value['description'])!=''){?>
                                    <div class="homeslider-description"><?php echo $_smarty_tpl->tpl_vars['slide']->value['description'];?>
</div>
                                <?php }?>
                            </div>
                            
                        </div>
                        <?php $_smarty_tpl->tpl_vars["first"] = new Smarty_variable(false, null, 0);?>
                    <?php }?>
                <?php } ?>
            </div>
        </div>
    <?php }?>
    <!-- /Module HomeSlider -->
<?php }?>

    <script type="text/javascript">
     $(document).ready(function() {
         $('.carousel').carousel({
              interval: 6000
            })
     });
    </script>
<?php }} ?>