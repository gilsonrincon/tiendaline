<?php /* Smarty version Smarty-3.1.14, created on 2014-04-21 08:53:40
         compiled from "D:\VPS\ptiendaline\admin8317\themes\default\template\controllers\modules\warning_module.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24180535522e4d96085-86745401%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '03aa37fc59bdef9d4f3a7a68159db576f6a76958' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\admin8317\\themes\\default\\template\\controllers\\modules\\warning_module.tpl',
      1 => 1395094664,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24180535522e4d96085-86745401',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'module_link' => 0,
    'text' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_535522e4de4296_36819299',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535522e4de4296_36819299')) {function content_535522e4de4296_36819299($_smarty_tpl) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['module_link']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['text']->value;?>
</a><?php }} ?>