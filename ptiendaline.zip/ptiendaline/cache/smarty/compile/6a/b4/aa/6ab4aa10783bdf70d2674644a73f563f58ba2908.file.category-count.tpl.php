<?php /* Smarty version Smarty-3.1.14, created on 2014-04-21 09:06:56
         compiled from "D:\VPS\ptiendaline\themes\plan1-tema1\category-count.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6061535526008c5a76-41550689%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6ab4aa10783bdf70d2674644a73f563f58ba2908' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\themes\\plan1-tema1\\category-count.tpl',
      1 => 1395935301,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6061535526008c5a76-41550689',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'category' => 0,
    'nb_products' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_535526008f86f0_28443835',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535526008f86f0_28443835')) {function content_535526008f86f0_28443835($_smarty_tpl) {?>
<span class="heading-counter"><?php if ($_smarty_tpl->tpl_vars['category']->value->id==1||$_smarty_tpl->tpl_vars['nb_products']->value==0){?><?php echo smartyTranslate(array('s'=>'There are no products in  this category'),$_smarty_tpl);?>
<?php }else{ ?><?php if ($_smarty_tpl->tpl_vars['nb_products']->value==1){?><?php echo smartyTranslate(array('s'=>'There is %d product.','sprintf'=>$_smarty_tpl->tpl_vars['nb_products']->value),$_smarty_tpl);?>
<?php }else{ ?><?php echo smartyTranslate(array('s'=>'There are %d products.','sprintf'=>$_smarty_tpl->tpl_vars['nb_products']->value),$_smarty_tpl);?>
<?php }?><?php }?></span><?php }} ?>