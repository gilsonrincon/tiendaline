<?php /* Smarty version Smarty-3.1.14, created on 2014-04-14 16:09:56
         compiled from "D:\VPS\ptiendaline\admin8317\themes\default\template\helpers\list\list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:72534c4ea4200401-08668293%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '126eba6076e36cc24c82e745c0d9a81083333031' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\admin8317\\themes\\default\\template\\helpers\\list\\list.tpl',
      1 => 1395094664,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '72534c4ea4200401-08668293',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'content' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534c4ea4208106_44895826',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534c4ea4208106_44895826')) {function content_534c4ea4208106_44895826($_smarty_tpl) {?>
<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>