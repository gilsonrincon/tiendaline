<?php /* Smarty version Smarty-3.1.14, created on 2014-04-21 15:44:08
         compiled from "D:\VPS\ptiendaline\modules\blockproductcontact\productcontact.tpl" */ ?>
<?php /*%%SmartyHeaderCode:37753558318ef4367-47059346%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2f7323ebae2e11e50ba850c95d1e40d5c60f8432' => 
    array (
      0 => 'D:\\VPS\\ptiendaline\\modules\\blockproductcontact\\productcontact.tpl',
      1 => 1397145347,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '37753558318ef4367-47059346',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'msgOk' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_53558318f0f8f7_31232535',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53558318f0f8f7_31232535')) {function content_53558318f0f8f7_31232535($_smarty_tpl) {?>

<!-- blockproductcontact -->
<form onsubmit="return validateContactForm(this);" class="box" method="post" role="form" id="contact-product">
	<?php if (isset($_smarty_tpl->tpl_vars['msgOk']->value)){?>
		<div class="alert alert-info">
			<?php echo $_smarty_tpl->tpl_vars['msgOk']->value;?>

		</div>
	<?php }?>
	<h2><?php echo smartyTranslate(array('s'=>'Contact Us','mod'=>'blockproductcontact'),$_smarty_tpl);?>
</h2>
	<div class="form-group">
		<input class="form-control" id="name" type="text" name="name" placeholder="<?php echo smartyTranslate(array('s'=>'NAME:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required>
	</div>
	
	<div class="form-group">
		<input class="form-control" id="telephone" type="tel" name="telephone" placeholder="<?php echo smartyTranslate(array('s'=>'TELEPHONE:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required>
	</div>
	
	<div class="form-group">
		<input class="form-control" id="email" type="email" name="email" placeholder="<?php echo smartyTranslate(array('s'=>'E-MAIL:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required>
	</div>
	
	<div class="form-group">
		<textarea class="form-control" id="comments" name="comments" placeholder="<?php echo smartyTranslate(array('s'=>'MESSAGE:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required></textarea>
	</div>
	
	<button id="btn-send-contact" class="btn" type="submit" name="contactSubmit"><?php echo smartyTranslate(array('s'=>'SUBMIT','mod'=>'blockproductcontact'),$_smarty_tpl);?>
</button>
	<!--
	<button id="btn-send-contact  " class="btn btn-default btn-info " type="submit" name="contactSubmit"><?php echo smartyTranslate(array('s'=>'SUBMIT','mod'=>'blockproductcontact'),$_smarty_tpl);?>
</button>
	-->
</form>


<script type="text/javascript">
	function validateContactForm(obj) {
		var b=true;
		$('[required]').each(function(){
			if($(this).val()==''){
				b=false;
			}
		});

		return b;
	}
</script>

<!-- end blockproductcontact --><?php }} ?>