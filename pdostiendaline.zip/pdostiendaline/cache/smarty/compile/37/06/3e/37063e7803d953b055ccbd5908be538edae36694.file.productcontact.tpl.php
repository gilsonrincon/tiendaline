<?php /* Smarty version Smarty-3.1.14, created on 2014-04-21 09:45:49
         compiled from "D:\VPS\pdostiendaline\modules\blockproductcontact\productcontact.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1293853552f1dadaa69-73233488%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '37063e7803d953b055ccbd5908be538edae36694' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\modules\\blockproductcontact\\productcontact.tpl',
      1 => 1397145347,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1293853552f1dadaa69-73233488',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'msgOk' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_53552f1db24df9_93512357',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53552f1db24df9_93512357')) {function content_53552f1db24df9_93512357($_smarty_tpl) {?>

<!-- blockproductcontact -->
<form onsubmit="return validateContactForm(this);" class="box" method="post" role="form" id="contact-product">
	<?php if (isset($_smarty_tpl->tpl_vars['msgOk']->value)){?>
		<div class="alert alert-info">
			<?php echo $_smarty_tpl->tpl_vars['msgOk']->value;?>

		</div>
	<?php }?>
	<h2><?php echo smartyTranslate(array('s'=>'Contact Us','mod'=>'blockproductcontact'),$_smarty_tpl);?>
</h2>
	<div class="form-group">
		<input class="form-control" id="name" type="text" name="name" placeholder="<?php echo smartyTranslate(array('s'=>'NAME:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required>
	</div>
	
	<div class="form-group">
		<input class="form-control" id="telephone" type="tel" name="telephone" placeholder="<?php echo smartyTranslate(array('s'=>'TELEPHONE:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required>
	</div>
	
	<div class="form-group">
		<input class="form-control" id="email" type="email" name="email" placeholder="<?php echo smartyTranslate(array('s'=>'E-MAIL:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required>
	</div>
	
	<div class="form-group">
		<textarea class="form-control" id="comments" name="comments" placeholder="<?php echo smartyTranslate(array('s'=>'MESSAGE:','mod'=>'blockproductcontact'),$_smarty_tpl);?>
" required></textarea>
	</div>
	
	<button id="btn-send-contact" class="btn" type="submit" name="contactSubmit"><?php echo smartyTranslate(array('s'=>'SUBMIT','mod'=>'blockproductcontact'),$_smarty_tpl);?>
</button>
	<!--
	<button id="btn-send-contact  " class="btn btn-default btn-info " type="submit" name="contactSubmit"><?php echo smartyTranslate(array('s'=>'SUBMIT','mod'=>'blockproductcontact'),$_smarty_tpl);?>
</button>
	-->
</form>


<script type="text/javascript">
	function validateContactForm(obj) {
		var b=true;
		$('[required]').each(function(){
			if($(this).val()==''){
				b=false;
			}
		});

		return b;
	}
</script>

<!-- end blockproductcontact --><?php }} ?>