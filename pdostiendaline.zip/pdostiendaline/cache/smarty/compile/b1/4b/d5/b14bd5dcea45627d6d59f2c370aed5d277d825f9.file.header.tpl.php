<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 15:52:52
         compiled from "D:\VPS\pdostiendaline\modules\homeslider\views\templates\hook\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5747534d9c24063c32-80205870%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b14bd5dcea45627d6d59f2c370aed5d277d825f9' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\modules\\homeslider\\views\\templates\\hook\\header.tpl',
      1 => 1397511716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5747534d9c24063c32-80205870',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'homeslider' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d9c240a2442_72183111',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d9c240a2442_72183111')) {function content_534d9c240a2442_72183111($_smarty_tpl) {?><?php if (isset($_smarty_tpl->tpl_vars['homeslider']->value)){?>
<script type="text/javascript">
     var homeslider_loop=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['loop'];?>
;
     var homeslider_width=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['width'];?>
;
     var homeslider_speed=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['speed'];?>
;
     var homeslider_pause=<?php echo $_smarty_tpl->tpl_vars['homeslider']->value['pause'];?>
;
</script>
<?php }?><?php }} ?>