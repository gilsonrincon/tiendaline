<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 15:52:52
         compiled from "D:\VPS\pdostiendaline\themes\default-bootstrap\modules\homeslider\homeslider.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7226534d9c24570ce4-72227557%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a84283c54e76a907185f24c6fc43fc547237a6ca' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\homeslider\\homeslider.tpl',
      1 => 1397573345,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7226534d9c24570ce4-72227557',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'page_name' => 0,
    'homeslider_slides' => 0,
    'slide' => 0,
    'first' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d9c245b3379_14728130',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d9c245b3379_14728130')) {function content_534d9c245b3379_14728130($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['page_name']->value=='index'){?>
    <!-- Module HomeSlider -->
    <?php if (isset($_smarty_tpl->tpl_vars['homeslider_slides']->value)){?>
        <div id="bannerHome" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php $_smarty_tpl->tpl_vars["first"] = new Smarty_variable(true, null, 0);?>
                <?php  $_smarty_tpl->tpl_vars['slide'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['slide']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['homeslider_slides']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['slide']->key => $_smarty_tpl->tpl_vars['slide']->value){
$_smarty_tpl->tpl_vars['slide']->_loop = true;
?>
                    <?php if ($_smarty_tpl->tpl_vars['slide']->value['active']){?>
                        <div class="item<?php if ($_smarty_tpl->tpl_vars['first']->value==true){?> active<?php }?>">
                            <a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['url'], ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['legend'], ENT_QUOTES, 'UTF-8', true);?>
">
                                <img src="<?php echo $_smarty_tpl->tpl_vars['link']->value->getMediaLink(((string)@constant('_MODULE_DIR_'))."homeslider/images/".((string)mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['image'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8')));?>
" width="100%" height="100%" alt="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['slide']->value['legend'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" />
                            </a>
                            <div class="carousel-caption">
                                <?php if (isset($_smarty_tpl->tpl_vars['slide']->value['description'])&&trim($_smarty_tpl->tpl_vars['slide']->value['description'])!=''){?>
                                    <div class="homeslider-description"><?php echo $_smarty_tpl->tpl_vars['slide']->value['description'];?>
</div>
                                <?php }?>
                            </div>
                            
                        </div>
                        <?php $_smarty_tpl->tpl_vars["first"] = new Smarty_variable(false, null, 0);?>
                    <?php }?>
                <?php } ?>
            </div>
        </div>
    <?php }?>
    <!-- /Module HomeSlider -->
<?php }?>

    <script type="text/javascript">
     $(document).ready(function() {
         $('.carousel').carousel({
              interval: 5000
            })
     });
    </script>
<?php }} ?>