<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 14:23:39
         compiled from "D:\VPS\pdostiendaline\admin6128\themes\default\template\controllers\modules\warning_module.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6851534d873b83eea5-64079280%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c99c0f18e58131e4fb120b4ae13de4481da97c7' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\admin6128\\themes\\default\\template\\controllers\\modules\\warning_module.tpl',
      1 => 1395094664,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6851534d873b83eea5-64079280',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'module_link' => 0,
    'text' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d873b8a0948_19397449',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d873b8a0948_19397449')) {function content_534d873b8a0948_19397449($_smarty_tpl) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['module_link']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['text']->value;?>
</a><?php }} ?>