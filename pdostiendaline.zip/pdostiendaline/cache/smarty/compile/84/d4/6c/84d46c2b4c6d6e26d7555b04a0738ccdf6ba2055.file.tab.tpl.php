<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 14:19:15
         compiled from "D:\VPS\pdostiendaline\themes\default-bootstrap\modules\productcomments\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9834534d8633c612e9-18644482%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '84d46c2b4c6d6e26d7555b04a0738ccdf6ba2055' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\productcomments\\tab.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9834534d8633c612e9-18644482',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d8633c65161_60237593',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d8633c65161_60237593')) {function content_534d8633c65161_60237593($_smarty_tpl) {?>

<h3 id="#idTab5" class="idTabHrefShort page-product-heading"><?php echo smartyTranslate(array('s'=>'Reviews','mod'=>'productcomments'),$_smarty_tpl);?>
</h3> <?php }} ?>