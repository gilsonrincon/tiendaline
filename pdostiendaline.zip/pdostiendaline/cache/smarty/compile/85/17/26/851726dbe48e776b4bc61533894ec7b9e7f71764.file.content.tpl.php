<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 14:19:00
         compiled from "D:\VPS\pdostiendaline\admin6128\themes\default\template\content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21120534d862481bec6-28911282%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '851726dbe48e776b4bc61533894ec7b9e7f71764' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\admin6128\\themes\\default\\template\\content.tpl',
      1 => 1395094664,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21120534d862481bec6-28911282',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d8624823bc8_36870717',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d8624823bc8_36870717')) {function content_534d8624823bc8_36870717($_smarty_tpl) {?>
<div id="ajax_confirmation" class="alert alert-success hide"></div>

<div id="ajaxBox" style="display:none"></div>

<?php if (isset($_smarty_tpl->tpl_vars['content']->value)){?>
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php }?>
<?php }} ?>