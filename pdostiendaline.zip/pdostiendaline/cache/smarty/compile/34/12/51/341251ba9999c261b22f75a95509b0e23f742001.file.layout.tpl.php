<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 15:31:23
         compiled from "D:\VPS\pdostiendaline\admin6128\themes\default\template\controllers\login\layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:22198534d971b2be6d0-47046973%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '341251ba9999c261b22f75a95509b0e23f742001' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\admin6128\\themes\\default\\template\\controllers\\login\\layout.tpl',
      1 => 1395094664,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22198534d971b2be6d0-47046973',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'page' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d971b2c63d2_68620387',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d971b2c63d2_68620387')) {function content_534d971b2c63d2_68620387($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>