<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 14:19:03
         compiled from "D:\VPS\pdostiendaline\themes\default-bootstrap\modules\blockuserinfo\blockuserinfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6231534d86277da2f6-98860458%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e68a70c53baf6748150775535b538ae4ed217b96' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\blockuserinfo\\blockuserinfo.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6231534d86277da2f6-98860458',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d86277de171_04903483',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d86277de171_04903483')) {function content_534d86277de171_04903483($_smarty_tpl) {?><?php }} ?>