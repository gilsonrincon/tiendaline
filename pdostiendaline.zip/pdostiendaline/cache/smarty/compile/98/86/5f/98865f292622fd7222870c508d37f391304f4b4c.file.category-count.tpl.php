<?php /* Smarty version Smarty-3.1.14, created on 2014-04-15 14:19:03
         compiled from "D:\VPS\pdostiendaline\themes\default-bootstrap\category-count.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4526534d8627bf5065-02015321%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '98865f292622fd7222870c508d37f391304f4b4c' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\category-count.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4526534d8627bf5065-02015321',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'category' => 0,
    'nb_products' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d8627c0c762_84993927',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d8627c0c762_84993927')) {function content_534d8627c0c762_84993927($_smarty_tpl) {?>
<span class="heading-counter"><?php if ($_smarty_tpl->tpl_vars['category']->value->id==1||$_smarty_tpl->tpl_vars['nb_products']->value==0){?><?php echo smartyTranslate(array('s'=>'There are no products in  this category'),$_smarty_tpl);?>
<?php }else{ ?><?php if ($_smarty_tpl->tpl_vars['nb_products']->value==1){?><?php echo smartyTranslate(array('s'=>'There is %d product.','sprintf'=>$_smarty_tpl->tpl_vars['nb_products']->value),$_smarty_tpl);?>
<?php }else{ ?><?php echo smartyTranslate(array('s'=>'There are %d products.','sprintf'=>$_smarty_tpl->tpl_vars['nb_products']->value),$_smarty_tpl);?>
<?php }?><?php }?></span><?php }} ?>