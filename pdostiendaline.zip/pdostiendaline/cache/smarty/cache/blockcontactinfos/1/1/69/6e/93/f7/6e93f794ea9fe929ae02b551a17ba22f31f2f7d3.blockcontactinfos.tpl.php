<?php /*%%SmartyHeaderCode:16738534d86279e1be9-21086303%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6e93f794ea9fe929ae02b551a17ba22f31f2f7d3' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\blockcontactinfos\\blockcontactinfos.tpl',
      1 => 1397579358,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16738534d86279e1be9-21086303',
  'variables' => 
  array (
    'blockcontactinfos_phone' => 0,
    'blockcontactinfos_company' => 0,
    'blockcontactinfos_address' => 0,
    'blockcontactinfos_email' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d8627a14874_32068618',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d8627a14874_32068618')) {function content_534d8627a14874_32068618($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos" class="footer-block col-xs-12 col-sm-4">
	<div>
        <!--
        <h4>Información de la tienda</h4>
        -->
        <ul class="toggle-footer">
                            <li>
                   
                    <span>0123-456-789</span>
                </li>
                                    	<li>
            		My shop, Calle 1 #51-01            	</li>
                        
                        	<li>
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%69%6e%66%6f@%74%75%74%69%65%6e%64%61.%63%6f%6d " >&#x69;&#x6e;&#x66;&#x6f;&#x40;&#x74;&#x75;&#x74;&#x69;&#x65;&#x6e;&#x64;&#x61;&#x2e;&#x63;&#x6f;&#x6d;&#x20;</a></span>
            	</li>
                    </ul>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>