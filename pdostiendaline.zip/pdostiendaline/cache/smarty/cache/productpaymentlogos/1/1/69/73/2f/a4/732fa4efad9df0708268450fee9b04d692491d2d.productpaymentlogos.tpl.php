<?php /*%%SmartyHeaderCode:7253534d8633c0f255-31792917%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '732fa4efad9df0708268450fee9b04d692491d2d' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\modules\\productpaymentlogos\\views\\templates\\hook\\productpaymentlogos.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7253534d8633c0f255-31792917',
  'variables' => 
  array (
    'content_only' => 0,
    'banner_title' => 0,
    'banner_link' => 0,
    'module_dir' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d8633c518e9_32445151',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d8633c518e9_32445151')) {function content_534d8633c518e9_32445151($_smarty_tpl) {?><!-- Productpaymentlogos module -->
<div id="product_payment_logos">
	<div class="box-security">
    <h5 class="product-heading-h5"></h5> 
  	<a href="" title=""><img src="/modules/productpaymentlogos/img/payment-logo.png" alt=""/></a>
    </div>
</div>
  
<!-- /Productpaymentlogos module -->
<?php }} ?>