<?php /*%%SmartyHeaderCode:9935534d9c24205c16-50986380%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a0d3dfde907f14b59545f4915914d9f24312648' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\homefeatured\\homefeatured.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
    'f4596db9f73e217a7471adacd971cdc318149909' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\product-list.tpl',
      1 => 1397510440,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9935534d9c24205c16-50986380',
  'variables' => 
  array (
    'products' => 0,
    'active_ul' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d9c2450b3c5_38688991',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d9c2450b3c5_38688991')) {function content_534d9c2450b3c5_38688991($_smarty_tpl) {?>
		
									
		
	
	<!-- Products list -->
	<ul id="homefeatured" class="product_list grid row homefeatured tab-pane active">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="http://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link"	href="http://p2tiendaline.com/home/8-portatil.html" title="PORTATIL" itemprop="url">
							<img class="replace-2x img-responsive" src="http://p2tiendaline.com/24-home_default/portatil.jpg" alt="PORTATIL" title="PORTATIL"  width="250" height="250" itemprop="image" />
						</a>
													<a class="quick-view" href="http://p2tiendaline.com/home/8-portatil.html" rel="http://p2tiendaline.com/home/8-portatil.html">
								<span>Vista r&aacute;pida</span>
							</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										$ 580.000									</span>
									<meta itemprop="priceCurrency" content="0" />
																								</div>
																							</div>
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://p2tiendaline.com/home/8-portatil.html" title="PORTATIL" itemprop="url" >
							PORTATIL
						</a>
					</h5>
					
					<p class="product-desc" itemprop="description">
						es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno est&aacute;ndar de las industrias desde el a&ntilde;o 1500, cuando un impresor
					</p>
										<div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
													<span itemprop="price" class="price product-price">
								$ 580.000							</span>
							<meta itemprop="priceCurrency" content="0" />
																		</div>
										<div class="button-container">
																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://p2tiendaline.com/carro-de-la-compra?add=1&amp;id_product=8&amp;token=7a9586fe65851b9d2575e75c7718a983" rel="nofollow" title="A&ntilde;adir al carrito" data-id-product="8">
										<span>A&ntilde;adir al carrito</span>
									</a>
														
																			<a itemprop="url" class="button lnk_view btn btn-default" href="http://p2tiendaline.com/home/8-portatil.html" title="Ver">
							<span>M&aacute;s</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
																	<span class="available-now">
										<link itemprop="availability" href="http://schema.org/InStock" />En stock
									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>