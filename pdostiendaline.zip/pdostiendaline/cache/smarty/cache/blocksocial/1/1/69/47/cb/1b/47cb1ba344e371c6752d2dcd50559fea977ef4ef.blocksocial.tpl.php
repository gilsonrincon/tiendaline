<?php /*%%SmartyHeaderCode:26669534d862798bcd7-67428491%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '47cb1ba344e371c6752d2dcd50559fea977ef4ef' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '26669534d862798bcd7-67428491',
  'variables' => 
  array (
    'facebook_url' => 0,
    'twitter_url' => 0,
    'rss_url' => 0,
    'youtube_url' => 0,
    'google_plus_url' => 0,
    'pinterest_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d86279d6067_73490502',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d86279d6067_73490502')) {function content_534d86279d6067_73490502($_smarty_tpl) {?>
<section id="social_block">
	<ul>
					<li class="facebook">
				<a target="_blank" href="http://www.facebook.com/tiendalinecolombia">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a target="_blank" href="http://www.twitter.com/prestashop">
					<span>Twitter</span>
				</a>
			</li>
				                        	</ul>
    <h4>Siganos</h4>
</section>
<div class="clearfix"></div>
<?php }} ?>