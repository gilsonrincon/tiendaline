<?php /*%%SmartyHeaderCode:13680535525101257b9-87419553%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd2bc497e0a8ed29674e542a54bf23fc8d2885aa9' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\modules\\blocksocial\\blocksocial-top.tpl',
      1 => 1397071785,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13680535525101257b9-87419553',
  'variables' => 
  array (
    'facebook_url' => 0,
    'twitter_url' => 0,
    'rss_url' => 0,
    'youtube_url' => 0,
    'google_plus_url' => 0,
    'pinterest_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_535525101a6653_62812341',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535525101a6653_62812341')) {function content_535525101a6653_62812341($_smarty_tpl) {?>
<div id="social_block">
	<!--
	<h4 class="title_block">Follow us</h4>
	-->
	<ul>
		<li class="facebook"><a href="http://www.facebook.com/tiendalinecolombia"><span>Facebook</span></a></li>		<li class="twitter"><a href="http://www.twitter.com/prestashop"><span>Twitter</span></a></li>									</ul>
</div>
<?php }} ?>