<?php /*%%SmartyHeaderCode:31145534d9c2414a3e4-25205352%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0945b850c1207478f3c9019536af669be800e181' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\modules\\blockfacebook\\blockfacebook.tpl',
      1 => 1397576913,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31145534d9c2414a3e4-25205352',
  'variables' => 
  array (
    'facebookurl' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d9c24161af6_91964607',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d9c24161af6_91964607')) {function content_534d9c24161af6_91964607($_smarty_tpl) {?><div id="fb-root"></div>
<div id="facebook_block" class="col-xs-4">
	<h4 >Síguenos en Facebook</h4>
	<div class="facebook-fanbox">
		<div class="fb-like-box" data-href="https://www.facebook.com/Tiendalinecolombia" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false">
		</div>
	</div>
</div>
<?php }} ?>