<?php /*%%SmartyHeaderCode:20852534d8628454038-51283226%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ff6dcd07e6b4bc5fec35265bfb0c6830bbf9022d' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\blockcontact\\nav.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20852534d8628454038-51283226',
  'variables' => 
  array (
    'link' => 0,
    'telnumber' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d862846f5b8_57412162',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d862846f5b8_57412162')) {function content_534d862846f5b8_57412162($_smarty_tpl) {?><div id="contact-link">
	<a href="http://p2tiendaline.com/contactenos" title="Contacta con nosotros">Contacta con nosotros</a>
</div>
<?php }} ?>