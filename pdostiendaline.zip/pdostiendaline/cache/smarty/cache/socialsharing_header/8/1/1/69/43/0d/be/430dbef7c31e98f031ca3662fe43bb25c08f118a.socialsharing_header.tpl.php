<?php /*%%SmartyHeaderCode:8089534d86338f2390-55851021%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '430dbef7c31e98f031ca3662fe43bb25c08f118a' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\modules\\socialsharing\\views\\templates\\hook\\socialsharing_header.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8089534d86338f2390-55851021',
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_53551efd74c059_76844138',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53551efd74c059_76844138')) {function content_53551efd74c059_76844138($_smarty_tpl) {?><meta property="og:title" content="" />
<meta property="og:type" content="product" />
<meta property="og:site_name" content="" />
<meta property="og:description" content="" />
<meta property="og:email" content="" />
<meta property="og:phone_number" content="" />
<meta property="og:street-address" content="" />
<meta property="og:locality" content="" />
<meta property="og:country-name" content="" />
<meta property="og:postal-code" content="" />
<meta property="og:image" content="http://p2tiendaline.com/24-large_default/portatil.jpg" />
<?php }} ?>