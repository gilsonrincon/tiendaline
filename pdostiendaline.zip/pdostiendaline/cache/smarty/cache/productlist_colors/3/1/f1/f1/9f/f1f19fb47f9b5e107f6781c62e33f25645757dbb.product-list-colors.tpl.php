<?php /*%%SmartyHeaderCode:3908534d86278bcc21-42794115%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1f19fb47f9b5e107f6781c62e33f25645757dbb' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\product-list-colors.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3908534d86278bcc21-42794115',
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d862790ecb1_37902504',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d862790ecb1_37902504')) {function content_534d862790ecb1_37902504($_smarty_tpl) {?>
<ul class="color_to_pick_list clearfix">
			<li>
			<a
			href="http://p2tiendaline.com/casual-dresses/3-printed-dress.html#/size-s/color-orange"
			id="color_13"
			class="color_pick"
			style="background: #F39C11;">
			</a>
		</li>
	</ul><?php }} ?>