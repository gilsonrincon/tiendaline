<?php /*%%SmartyHeaderCode:3908534d86278bcc21-42794115%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1f19fb47f9b5e107f6781c62e33f25645757dbb' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\product-list-colors.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3908534d86278bcc21-42794115',
  'variables' => 
  array (
    'colors_list' => 0,
    'color' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d86278eba38_50235266',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d86278eba38_50235266')) {function content_534d86278eba38_50235266($_smarty_tpl) {?>
<ul class="color_to_pick_list clearfix">
			<li>
			<a
			href="http://p2tiendaline.com/tshirts/1-faded-short-sleeve-tshirts.html#/size-s/color-blue"
			id="color_2"
			class="color_pick"
			style="background: #5D9CEC;">
			</a>
		</li>
			<li>
			<a
			href="http://p2tiendaline.com/tshirts/1-faded-short-sleeve-tshirts.html#/size-s/color-orange"
			id="color_1"
			class="color_pick"
			style="background: #F39C11;">
			</a>
		</li>
	</ul><?php }} ?>