<?php /*%%SmartyHeaderCode:732534d8627f02518-84719642%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c704d654ffd49d258f41509d82168a7ea8087a5d' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\productcomments\\productcomments_reviews.tpl',
      1 => 1395094666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '732534d8627f02518-84719642',
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d862802d734_13594274',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d862802d734_13594274')) {function content_534d862802d734_13594274($_smarty_tpl) {?> 
<?php }} ?>