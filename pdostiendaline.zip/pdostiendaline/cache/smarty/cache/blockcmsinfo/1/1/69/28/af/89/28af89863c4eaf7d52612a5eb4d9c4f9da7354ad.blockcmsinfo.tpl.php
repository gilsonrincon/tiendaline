<?php /*%%SmartyHeaderCode:18736534d9c2411f463-81399767%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '28af89863c4eaf7d52612a5eb4d9c4f9da7354ad' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\modules\\blockcmsinfo\\blockcmsinfo.tpl',
      1 => 1397576177,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18736534d9c2411f463-81399767',
  'variables' => 
  array (
    'infos' => 0,
    'info' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d9c2413e867_85540158',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d9c2413e867_85540158')) {function content_534d9c2413e867_85540158($_smarty_tpl) {?><!-- MODULE Block cmsinfo -->
<div id="cmsinfo_block">
					<div class="col-xs-6"><p><img src="/img/cms/pc.jpg" alt="imagen reperesentativa" width="301" height="201" /></p></div>
					<div class="col-xs-6"><p><strong class="dark"><span style="color: #63bae5;">Lorem Ipsum Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore e</span> </strong></p>
<p>Lorem Ipsum Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu Lorem Ipsum Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu Lorem Ipsum Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum</p></div>
		</div>
<!-- /MODULE Block cmsinfo -->
<?php }} ?>