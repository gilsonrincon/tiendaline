<?php /*%%SmartyHeaderCode:7226534d9c24570ce4-72227557%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a84283c54e76a907185f24c6fc43fc547237a6ca' => 
    array (
      0 => 'D:\\VPS\\pdostiendaline\\themes\\default-bootstrap\\modules\\homeslider\\homeslider.tpl',
      1 => 1397573345,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7226534d9c24570ce4-72227557',
  'variables' => 
  array (
    'page_name' => 0,
    'homeslider_slides' => 0,
    'slide' => 0,
    'first' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_534d9c245beef9_26733115',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_534d9c245beef9_26733115')) {function content_534d9c245beef9_26733115($_smarty_tpl) {?>    <!-- Module HomeSlider -->
            <div id="bannerHome" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                                                                            <div class="item active">
                            <a href="http://tiendaline.co/" title="banner 2">
                                <img src="http://p2tiendaline.com/modules/homeslider/images/c7c3892663ebd2137ef18c5cacde3f15.jpg" width="100%" height="100%" alt="banner 2" />
                            </a>
                            <div class="carousel-caption">
                                                            </div>
                            
                        </div>
                                                                        </div>
        </div>
        <!-- /Module HomeSlider -->

    <script type="text/javascript">
     $(document).ready(function() {
         $('.carousel').carousel({
              interval: 5000
            })
     });
    </script>
<?php }} ?>